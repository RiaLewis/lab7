from fastapi.responses import HTMLResponse
from h11 import Request
from . import router, templates
from app.dependencies.auth import AuthDep
from app.dependencies.session import SessionDep


@router.get("/app", response_class=HTMLResponse, name="app_dashbaord")
def app_dashboard(request: Request, db: SessionDep, user: AuthDep):
    
    todos = user.todos  # get logged-in user's todos

    return templates.TemplateResponse(
        request=request,
        name="todo.html",
        context={
            "current_user": user,
            "todos": todos
        }
    )